from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name='botas',
    version='0.1.0',
    packages=find_packages(),
    install_requires=[
        'requests>=2.28.0',
    ],
    description='A simple library for creating Telegram bots',
    long_description=long_description,
    long_description_content_type="text/markdown",  # Тип контента README
    author='Ваше Имя',
    author_email='ваш_email@example.com',
    url='https://github.com/ваш_пользователь/botas',
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
        'Development Status :: 3 - Alpha', # Или 4 - Beta
        'Intended Audience :: Developers',
        'Topic :: Communications :: Chat',
    ],
    python_requires='>=3.6',
)
